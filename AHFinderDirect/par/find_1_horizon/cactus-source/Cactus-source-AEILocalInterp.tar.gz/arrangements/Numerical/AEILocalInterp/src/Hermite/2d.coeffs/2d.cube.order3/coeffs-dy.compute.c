fp t749;
fp t748;
fp t779;
fp t778;
fp t777;
fp t747;
fp t776;
fp t775;
fp t741;
fp t759;
fp t684;
fp t708;
fp t774;
fp t727;
fp t773;
fp t738;
fp t762;
fp t681;
fp t723;
fp t772;
fp t713;
fp t771;
fp t770;
fp t769;
fp t664;
fp t709;
fp t768;
fp t767;
fp t728;
fp t696;
fp t739;
fp t676;
fp t766;
fp t764;
fp t711;
fp t765;
fp t678;
fp t763;
fp t719;
fp t666;
fp t761;
fp t760;
fp t758;
fp t757;
fp t722;
fp t698;
fp t756;
fp t742;
fp t755;
fp t745;
fp t707;
fp t754;
fp t714;
fp t699;
fp t753;
fp t743;
fp t752;
fp t751;
fp t746;
fp t744;
fp t740;
fp t737;
fp t736;
fp t735;
fp t734;
fp t733;
fp t732;
fp t731;
fp t730;
fp t729;
fp t726;
fp t725;
fp t724;
fp t720;
fp t718;
fp t717;
fp t716;
fp t715;
fp t706;
fp t705;
fp t704;
fp t703;
fp t702;
fp t701;
fp t697;
fp t695;
fp t694;
fp t693;
fp t692;
fp t691;
fp t690;
fp t689;
fp t686;
fp t683;
fp t679;
fp t677;
fp t674;
fp t673;
fp t672;
fp t671;
fp t663;
fp t662;
fp t660;
fp t659;
fp t656;
fp t654;
fp t650;
      t749 = x*x;
      t748 = t749*x;
      t779 = x+t748;
      t778 = y*t749;
      t777 = y*t748;
      t747 = y*y;
      t776 = x*t747;
      t775 = t747*t749;
      t741 = RATIONAL(1.0,3.0);
      t759 = t741*t747;
      t684 = t748*t759;
      t708 = RATIONAL(5.0,18.0);
      t774 = t684+t708*t778;
      t727 = RATIONAL(7.0,48.0);
      t773 = t727*t747;
      t738 = RATIONAL(-1.0,3.0);
      t762 = t738*t747;
      t681 = t748*t762;
      t723 = RATIONAL(-7.0,18.0);
      t772 = t723*t778+t681;
      t713 = RATIONAL(-7.0,48.0);
      t771 = t713*t747;
      t770 = t748*t747;
      t769 = t749*RATIONAL(-5.0,12.0);
      t664 = t727*t770;
      t709 = RATIONAL(5.0,24.0);
      t768 = t709*t778+t664;
      t767 = RATIONAL(-16.0,3.0)*t770+RATIONAL(-70.0,9.0)*t778;
      t728 = RATIONAL(7.0,18.0);
      t696 = t728*t748;
      t739 = RATIONAL(7.0,3.0);
      t676 = t739*t770;
      t766 = t676+t739*t778;
      t764 = t747*RATIONAL(-1.0,48.0);
      t711 = RATIONAL(-1.0,36.0);
      t765 = t748*t764+t711*t778;
      t678 = RATIONAL(-7.0,3.0)*t770;
      t763 = RATIONAL(-35.0,6.0)*t778+t678;
      t719 = RATIONAL(-1.0,12.0);
      t666 = t713*t770;
      t761 = t719*t778+t666;
      t760 = RATIONAL(1.0,48.0)*t747;
      t758 = t684+RATIONAL(7.0,9.0)*t778;
      t757 = t779*y;
      t722 = RATIONAL(1.0,18.0);
      t698 = t722*x;
      t756 = RATIONAL(-49.0,48.0)*t770+RATIONAL(-5.0,4.0)*t778+t698;
      t742 = RATIONAL(-4.0,9.0);
      t755 = t676+RATIONAL(25.0,6.0)*t778+t742*x;
      t745 = RATIONAL(1.0,6.0);
      t707 = RATIONAL(-1.0,144.0);
      t754 = t707*x+t745*t778+t664;
      t714 = RATIONAL(-1.0,18.0);
      t699 = t714*x;
      t753 = t699+y*t769+t666;
      t743 = RATIONAL(-5.0,3.0);
      t752 = t743*t778+t678+t699;
      t751 = RATIONAL(-5.0,9.0)*t778+t681+t698;
      t746 = RATIONAL(4.0,9.0);
      t744 = RATIONAL(-2.0,3.0);
      t740 = RATIONAL(-2.0,9.0);
      t737 = RATIONAL(2.0,9.0);
      t736 = RATIONAL(-1.0,9.0);
      t735 = RATIONAL(2.0,3.0);
      t734 = RATIONAL(1.0,9.0);
      t733 = RATIONAL(1.0,72.0);
      t732 = RATIONAL(-5.0,24.0);
      t731 = RATIONAL(-7.0,12.0);
      t730 = RATIONAL(-1.0,24.0);
      t729 = RATIONAL(1.0,12.0);
      t726 = RATIONAL(-7.0,36.0);
      t725 = RATIONAL(1.0,24.0);
      t724 = RATIONAL(10.0,3.0);
      t720 = RATIONAL(-5.0,18.0);
      t718 = RATIONAL(7.0,12.0);
      t717 = RATIONAL(7.0,36.0);
      t716 = RATIONAL(-1.0,72.0);
      t715 = RATIONAL(1.0,36.0);
      t706 = RATIONAL(1.0,144.0);
      t705 = t736*t748;
      t704 = t734*t748;
      t703 = t746*x;
      t702 = RATIONAL(-8.0,9.0)*t748;
      t701 = RATIONAL(8.0,9.0)*t748;
      t697 = t714*t748;
      t695 = t723*t748;
      t694 = t722*t748;
      t693 = t706*t748;
      t692 = t706*x;
      t691 = RATIONAL(-7.0,144.0)*t748;
      t690 = RATIONAL(7.0,144.0)*t748;
      t689 = t707*t748;
      t686 = t745*t776;
      t683 = RATIONAL(-1.0,6.0)*t776;
      t679 = RATIONAL(7.0,6.0)*t776;
      t677 = RATIONAL(-7.0,6.0)*t776;
      t674 = x*t759;
      t673 = RATIONAL(-8.0,3.0)*t776;
      t672 = RATIONAL(8.0,3.0)*t776;
      t671 = x*t762;
      t663 = x*t764;
      t662 = t748*t760;
      t660 = x*t760;
      t659 = x*t771;
      t656 = x*t773;
      t654 = RATIONAL(16.0,3.0)*t770;
      t650 = RATIONAL(49.0,48.0)*t770;
      coeffs_dy->coeff_m2_m2 = t693+t692+t660+t662+(t716+t730*t747)*t749+(t722*
t749+t779*t711)*y;
      coeffs_dy->coeff_m1_m2 = t691+t683+(RATIONAL(5.0,48.0)+RATIONAL(5.0,16.0)
*t747)*t749+(t737*x+t717*t748)*y+t753;
      coeffs_dy->coeff_0_m2 = t729+t726*t749+t704+(t731*t749+RATIONAL(1.0,4.0))
*t747+(t742*t748+t738)*y+t758;
      coeffs_dy->coeff_p1_m2 = t705+t686+(RATIONAL(5.0,12.0)*t747+RATIONAL(5.0,
36.0))*t749+(t740*x+t746*t748)*y+t751;
      coeffs_dy->coeff_p2_m2 = t663+t690+(t730+RATIONAL(-1.0,8.0)*t747)*t749+(
t715*x+t726*t748)*y+t754;
      coeffs_dy->coeff_p3_m2 = t715*t777+t689+(t706+t760)*t749+t765;
      coeffs_dy->coeff_m2_m1 = t659+t697+(RATIONAL(7.0,24.0)*t747+t734)*t749+
t709*t757+t753;
      coeffs_dy->coeff_m1_m1 = t696+t650+t703+t679+(RATIONAL(-5.0,6.0)+RATIONAL
(-35.0,16.0)*t747)*t749+(RATIONAL(25.0,8.0)*t749+t743*x+RATIONAL(-35.0,24.0)*
t748)*y;
      coeffs_dy->coeff_0_m1 = t702+RATIONAL(14.0,9.0)*t749+t744+(RATIONAL(-7.0,
4.0)+RATIONAL(49.0,12.0)*t749)*t747+(RATIONAL(5.0,2.0)+t724*t748)*y+t763;
      coeffs_dy->coeff_p1_m1 = t677+t701+(RATIONAL(-35.0,12.0)*t747+RATIONAL(
-10.0,9.0))*t749+(RATIONAL(-10.0,3.0)*t748+RATIONAL(5.0,3.0)*x)*y+t755;
      coeffs_dy->coeff_p2_m1 = t695+t656+(RATIONAL(7.0,8.0)*t747+t741)*t749+(
t732*x+RATIONAL(35.0,24.0)*t748)*y+t756;
      coeffs_dy->coeff_p3_m1 = t732*t777+t694+(t714+t771)*t749+t768;
      coeffs_dy->coeff_m2_0 = t744*t775+t674+t723*t757+t758;
      coeffs_dy->coeff_m1_0 = RATIONAL(5.0,1.0)*t775+t673+(RATIONAL(28.0,9.0)*x
+RATIONAL(49.0,18.0)*t748)*y+t763;
      coeffs_dy->coeff_0_0 = t654+(RATIONAL(4.0,1.0)+RATIONAL(-28.0,3.0)*t749)*
t747+(RATIONAL(-14.0,3.0)+RATIONAL(-56.0,9.0)*t748+RATIONAL(98.0,9.0)*t749)*y;
      coeffs_dy->coeff_p1_0 = RATIONAL(20.0,3.0)*t775+t672+(RATIONAL(56.0,9.0)*
t748+RATIONAL(-28.0,9.0)*x)*y+t767;
      coeffs_dy->coeff_p2_0 = t671+RATIONAL(-2.0,1.0)*t775+(RATIONAL(-49.0,18.0
)*t748+t728*x)*y+t766;
      coeffs_dy->coeff_p3_0 = y*t696+t749*t759+t772;
      coeffs_dy->coeff_m2_p1 = t694+t671+(t735*t747+t736)*t749+t708*t757+t751;
      coeffs_dy->coeff_m1_p1 = t672+t695+(RATIONAL(5.0,6.0)+RATIONAL(-5.0,1.0)*
t747)*t749+(RATIONAL(-35.0,18.0)*t748+RATIONAL(-20.0,9.0)*x)*y+t755;
      coeffs_dy->coeff_0_p1 = RATIONAL(-14.0,9.0)*t749+t701+t735+(RATIONAL(-4.0
,1.0)+RATIONAL(28.0,3.0)*t749)*t747+(RATIONAL(40.0,9.0)*t748+t724)*y+t767;
      coeffs_dy->coeff_p1_p1 = t703+t702+t673+t654+(RATIONAL(-20.0,3.0)*t747+
RATIONAL(10.0,9.0))*t749+(RATIONAL(-40.0,9.0)*t748+RATIONAL(20.0,9.0)*x+
RATIONAL(50.0,9.0)*t749)*y;
      coeffs_dy->coeff_p2_p1 = t696+t674+(t738+RATIONAL(2.0,1.0)*t747)*t749+(
RATIONAL(35.0,18.0)*t748+t720*x)*y+t752;
      coeffs_dy->coeff_p3_p1 = t697+t720*t777+(t762+t722)*t749+t774;
      coeffs_dy->coeff_m2_p2 = t689+t656+(t733+RATIONAL(-7.0,24.0)*t747)*t749+
t719*t757+t754;
      coeffs_dy->coeff_m1_p2 = t677+t690+(RATIONAL(-5.0,48.0)+RATIONAL(35.0,
16.0)*t747)*t749+(t718*t748+t735*x)*y+t756;
      coeffs_dy->coeff_0_p2 = t719+RATIONAL(-4.0,3.0)*t777+t717*t749+t705-y+(
RATIONAL(7.0,4.0)+RATIONAL(-49.0,12.0)*t749)*t747+t766;
      coeffs_dy->coeff_p1_p2 = t679+t704+(RATIONAL(35.0,12.0)*t747+RATIONAL(
-5.0,36.0))*t749+(t744*x+RATIONAL(4.0,3.0)*t748)*y+t752;
      coeffs_dy->coeff_p2_p2 = t659+t650+t692+t691+(t725+RATIONAL(-7.0,8.0)*
t747)*t749+(t729*x+RATIONAL(1.0,2.0)*t749+t731*t748)*y;
      coeffs_dy->coeff_p3_p2 = t693+t729*t777+(t773+t707)*t749+t761;
      coeffs_dy->coeff_m2_p3 = t663+t725*t775+t733*t757+t765;
      coeffs_dy->coeff_m1_p3 = t686+RATIONAL(-5.0,16.0)*t775+(RATIONAL(-7.0,
72.0)*t748+t736*x)*y+t768;
      coeffs_dy->coeff_0_p3 = (t718*t749+RATIONAL(-1.0,4.0))*t747+(t737*t748+
t745)*y+t772;
      coeffs_dy->coeff_p1_p3 = t683+t747*t769+(t740*t748+t734*x)*y+t774;
      coeffs_dy->coeff_p2_p3 = t660+RATIONAL(1.0,8.0)*t775+(RATIONAL(7.0,72.0)*
t748+t716*x)*y+t761;
      coeffs_dy->coeff_p3_p3 = t662+t749*t764+(t716*t748+t733*t749)*y;
